function Offspring = crossover(Problem,Parent,T_t)

    [proC,disC,proM,disM] = deal(1,20,1,20);
    % Parent=Parent.*T_t;
    Parent1 = Parent(1:floor(end/2),:);
    T_1=T_t(1:floor(end/2),:);
    T_2=T_t(floor(end/2)+1:floor(end/2)*2,:);
    T_val=abs(T_1)+abs(T_2);
    Parent2 = Parent(floor(end/2)+1:floor(end/2)*2,:);
    P1=(Parent1.*T_1)./T_val+(Parent2.*T_2)./T_val;
    P2=(Parent1.*T_1)./T_val-(Parent2.*T_2)./T_val;
   
    [N,D]   = size(Parent1);
    beta = zeros(N,D);
    mu   = rand(N,D);
    beta(mu<=0.5) = (2*mu(mu<=0.5)).^(1/(disC+1));
    beta(mu>0.5)  = (2-2*mu(mu>0.5)).^(-1/(disC+1));
    beta = beta.*(-1).^randi([0,1],N,D);
    beta(rand(N,D)<0.5) = 1;
    beta(repmat(rand(N,1)>proC,1,D)) = 1;
    
    P3=Parent1+Parent2;
    Offspring = [P1/2+beta.*P2
        P1/2-beta.*P2];
   

end
