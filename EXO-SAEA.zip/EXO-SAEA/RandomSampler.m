function [val,val1]=RandomSampler(X,Y,len)
val=[];
for i=1:len
    ind=randperm(size(X,1),1);
    t=X(ind,:);
    t1=Y(ind,:);
    val=[val;t];
    val1=[val1;t1];
end
end