classdef DatasetRepeat
    % A wrapper around multiple datasets that allows repeated elements when the
    % dataset sizes don't match. The number of elements is the maximum dataset
    % size, and all datasets must be broadcastable to the same size.

    properties
        datasets
        num_items
        items
    end

    methods
        function obj = DatasetRepeat(datasets)
            % Get maximum number of elements.
%             assert(all(cellfun(@(dset) isa(dset, 'matlab.io.Datastore'), datasets)));
            items = cellfun(@numel, datasets);
            num_items = max(items);

            % Ensure all datasets align.
            % assert(all(mod(num_items, items) == 0));
            obj.datasets = datasets;
            obj.num_items = num_items;
            obj.items = items;
        end

        function output = getitem(obj, index)
            assert(index >= 1 && index <= obj.num_items);
            return_items = cellfun(@(dset, num) dset{mod(index-1, num)+1}, obj.datasets, obj.items, 'UniformOutput', false);
            output = cell2mat(return_items(:)');
        end

        function length = len(obj)
            length = obj.num_items;
        end
    end
end